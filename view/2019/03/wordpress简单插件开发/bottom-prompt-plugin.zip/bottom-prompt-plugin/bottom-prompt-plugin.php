<?php  
/*
 * Plugin Name: Bottom-Prompt plugin
 * Plugin URI: http://www.zhuyuntao.cn
 * Description: 底部消息提示插件
 * Version: 1.0.0
 * Author: 2fps
 * Author URI: http://www.zhuyuntao.cn
 * License: GPL
 */

/* 注册激活插件时调用的函数 */ 
register_activation_hook( __FILE__, 'display_prompt_install');
/* 注册停用插件时调用的函数 */ 
register_deactivation_hook( __FILE__, 'display_prompt_remove');

add_filter('the_content', 'display_prompt');

if(is_admin()) {
    /*  利用 admin_menu 钩子，添加菜单 */
    add_action('admin_menu', 'ddisplay_prompt_menu');
}
function ddisplay_prompt_menu() {
    /* add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function);  */
    /* 页名称，菜单名称，访问级别，菜单别名，点击该菜单时的回调函数（用以显示设置页面） */
    add_options_page('set Prompt', 'Menu', 'administrator','display_prompt', 'display_prompt_html_page');
}

function display_prompt_html_page() {
    ?>
    <div class="wrap">  
        <h1>Set Prompt</h1>  
        <form method="post" action="options.php">  
            <?php /* 下面这行代码用来保存表单中内容到数据库 */ ?>  
            <?php wp_nonce_field('update-options'); ?>  
            <table class="form-table">
                <tr>
                    <th>提示</th>
                    <td>
                        <p>
                            <label>在此输入文章尾部的提示信息（支持html解析）。</label>
                        </p>
                        <p>
                            <textarea  
                                name="display_prompt_text" 
                                id="display_prompt_text" 
                                cols="50" 
                                class="large-text code"
                                rows="10"><?php echo get_option('display_prompt_text'); ?></textarea>  
                        </p>
                    </td>
                </tr>
            </table>
            <p>  
                <input type="hidden" name="action" value="update" />  
                <input type="hidden" name="page_options" value="display_prompt_text" />  
                <input type="submit" value="保存更改" class="button button-primary" class="button-primary" />
            </p>  
        </form>  
    </div>  
<?php  
}  

function display_prompt_install() {  
    /* 在数据库的 wp_options 表中添加一条记录，第二个参数为默认值 */ 
    add_option("display_prompt_text", "<p>欢迎关注微信公众号[ 我不会前端 ]或扫描右侧悬浮二维码。！</p>", '', 'yes');  
}
function display_prompt_remove() {  
    /* 删除 wp_options 表中的对应记录 */ 
    delete_option('display_prompt_text');  
}

function display_prompt($content) {  
    if (is_single()) {
        $content = $content.get_option('display_prompt_text'); 
    }  
 
    return $content;  
}






?> 
